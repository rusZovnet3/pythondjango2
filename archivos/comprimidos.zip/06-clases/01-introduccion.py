print("\n==========    ====================\n")

sms1 = "Jimena Claros"
sms2 = 25
sms3 = 3.45
sms4 = True
sms5 = ["ab", 45]
sms6 = ("er", "hola")
sms7 = {"x": 45, "y": "Carla"}


print(type(sms1))
print(type(sms2))
print(type(sms3))
print(type(sms4))
print(type(sms5))
print(type(sms6))
print(type(sms7))