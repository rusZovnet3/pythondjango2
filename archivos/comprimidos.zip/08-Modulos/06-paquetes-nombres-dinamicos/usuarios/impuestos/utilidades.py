#from ..gestion.crud import guardar

print(__name__)   # nombre de la ruta del archivo actual


def pagar_impuesto():
    print("pagando impuestos.....!, espere....")
    #guardar()
    
if __name__ == "__main__":
    print("Tarea de mantenimiento")