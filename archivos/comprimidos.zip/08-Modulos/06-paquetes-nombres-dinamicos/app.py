from usuarios.impuestos.utilidades import pagar_impuesto
# paquete, subpaquete, modulo  ---  funciones

#print("\n==========  paquetes con nombres dinamicos  ====================\n")

#pagar_impuesto()
print(__name__)     # nombre de la ruta del archivo actual