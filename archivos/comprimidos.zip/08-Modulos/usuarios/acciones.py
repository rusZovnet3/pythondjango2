def guardar():
    print("guardando")
    
def pagar_impuesto():
    print("pagando impuestos")
    
    