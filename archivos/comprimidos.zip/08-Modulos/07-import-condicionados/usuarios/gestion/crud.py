def guardar():
    print("guardando crud-gestion.....")
    
