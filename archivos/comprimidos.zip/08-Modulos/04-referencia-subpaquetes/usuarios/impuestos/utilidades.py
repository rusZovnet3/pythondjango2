# importando la funciones de guardar de la gestion

# cd

from ..gestion.crud import guardar

def pagar_impuesto():
    print("pagando impuestos.....!, nespere")
    guardar()