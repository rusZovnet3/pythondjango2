from usuarios.impuestos.utilidades import pagar_impuesto

# paquete, subpaquete, modulo  ---  funciones

#print("\n==========  referencia subpaquetes  ====================\n")

pagar_impuesto()
