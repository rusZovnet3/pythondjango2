from usuarios.impuestos.utilidades import pagar_impuesto
# paquete, subpaquete, modulo  ---  funciones

import usuarios
#print("\n==========  dir  ====================\n")

#print(dir(usuarios))

""" print(usuarios.__name__)
print(usuarios.__package__)
print(usuarios.__path__)
print(usuarios.__file__) """


print(usuarios.gestion.__name__)
print(usuarios.impuestos.__package__)
print(usuarios.gestion.__path__)
print(usuarios.impuestos.__file__)