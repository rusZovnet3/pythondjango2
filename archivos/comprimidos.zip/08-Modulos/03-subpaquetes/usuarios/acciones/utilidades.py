def guardar():
    print("guardando")
    
def pagar_impuesto():
    print("pagando impuestos")
    
def formatear_BD():
    print("Formateando toda la BD") 