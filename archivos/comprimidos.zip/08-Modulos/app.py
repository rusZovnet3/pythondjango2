from usuarios import acciones   # 3

#import usuarios.acciones   # 2
#from usuarios.acciones import guardar, pagar_impuesto   # 1



#print("\n==========  Modulos y Paquetes  ====================\n")

# from  = referencia
# carpetas = paquetes
# nombre archivos = paquetes
# funciones = modulos

# guardar()       # 1


# otra forma de referencia    # 2

#usuarios.acciones.guardar()    # 2

# otra forma especifica  # 3  , importar el paquete completo de los modulos

acciones.pagar_impuesto()

