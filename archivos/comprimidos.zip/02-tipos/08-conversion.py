print("=============  conversion =============\n")


'''
    int()
    str()
    float()
    bool()
'''

print(f'bool("")    ===>    {bool("")}')
print(f'bool("0")   ===>    {bool("0")}')
print(f'bool(None)  ===>    {bool(None)}')
print(f'bool(" ")   ===>    {bool(" ")}')
print(f'bool(0)     ===>    {bool(0)}')
