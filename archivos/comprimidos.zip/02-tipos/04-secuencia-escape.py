print("=============  secuencia escape  =============\n")

'''

\"
\'
\\
\n

'''


curso1 = 'Ultimate "Windows"'
curso2 = "Ultimate \"Python\""
curso3 = "design \\web\""
curso4 = "Ultimate \nPython\""

print(curso1)
print(curso2)
print(curso3)
print("\n")
print(curso4)


