print("=============  números  =============\n")

num = 5                 # integer
fraccion = 5.7          # float
imaginario = 5 + 3j     # 5 + 3i


num += 2    # 5 + 2 = 7

print("numero", num)

num *=3     # 7 * 3 = 21

print("numero", num)

num -= 6    # 21 - 6 = 15
print("numero", num)

num /= 9   # 15 / 9 = 1.666666
print("numero", num)

print("\t\t\t------------\n")

print(5 + 2)
print(5 - 2)
print(5 * 2)
print(11 / 4)           # division normal
print(11 // 4)          # division , sin decimal
print(11 % 4)           # el primer residuo de la division

print(3 ** 4)           # a ^ b

