print("============  STRING  ============\n")

nom = "Maria Victoria"
ape = "Orellana Meyui"

print("-------- formateo de string ---------\n")
com = f"{nom} {ape}"
print(com)

print("\t\t\t-------- omite los datos string con int  ---------\n")
omi = f"{nom[0:2]} {5 + 2}"
print(omi)

