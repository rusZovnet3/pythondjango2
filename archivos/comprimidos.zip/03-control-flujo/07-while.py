print("============= while  =============\n")

""" numero = 1

while numero < 100:
    print(numero)
    numero *=2 """



    
""" cmd = ""

while cmd.lower() != "salir":
    cmd = input("$ ")
    print(cmd) """
    

while True:
    coman = input("$ ")
    print(coman)
    if coman.lower() == "salir":
        break
    