print("============= for  =============\n")

#for num in range(5):
#    print(num)

#for numero in range(5):
#    print(numero, numero * 'Jessica Villena ')


print("\n\============= for else  =============\n")
#buscar = input("Escriba un numero: ")
#buscar = int(buscar)


#for num in range(10):
    #print(num)   # verificar cuantas veces realizo la busqueda
#    if num == buscar:
#        print("encontrado", buscar)
#        break
#else:
#    print("no se encontro nada")
    
    
print("\n\============= Iterable  =============\n")   

for caracter in "Developer Web":
    print(caracter)



