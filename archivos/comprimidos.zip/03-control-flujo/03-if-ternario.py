print("=============  if --- operador ternario =============\n")

edad = input("Ingresa tu edad: ")
edad = int(edad)

mensaje = "Eres Mayor" if edad > 17 else "Eres Menor"
print(mensaje)



