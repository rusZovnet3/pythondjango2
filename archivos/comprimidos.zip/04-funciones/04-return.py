print("\n========================  return  =================================")

def suma(a, b):
    resu = a + b
    return resu

c = suma(2, 3)
d = suma(c, 7)
print(d)