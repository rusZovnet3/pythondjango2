def init(graphql, **_):
    print(f"Soy Modulo Uno: {graphql}")