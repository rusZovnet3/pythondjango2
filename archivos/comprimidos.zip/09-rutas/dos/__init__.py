def init(db, api, **_):
    print(f"Soy Modulo Dos: {db} {api}")