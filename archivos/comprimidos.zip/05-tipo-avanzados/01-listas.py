print("\n========================  Listas =================================")

num = [1, 2, 45, 45]
let = ["a", 'b', '15', "T"]
pal = ["python", "diseño web"]
boo = [True, False, True]
matriz = [45, ["Hola", 12, "Lurdes", [78, "30", False], 58], "Feliz", [14, True], 0, "J"]
ceros = [0] * 10

unir_lista = num + let
rango = list(range(1, 11))
chars = list("martin sapee")

#print(ceros)
#print(unir_lista)
#print(rango)
print(chars)


